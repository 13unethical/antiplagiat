<?php
/**
 * Webhook receiver for Antiplagiat check.completed events.
 * Verifies X-Antiplagiat-Signature HMAC-SHA256 when webhook secret is set.
 */
define('AJAX_SCRIPT', true);

require_once(__DIR__ . '/../../config.php');
require_once($CFG->dirroot . '/plagiarism/antiplagiat/lib.php');

$raw = file_get_contents('php://input');
$secret = trim(get_config('plagiarism_antiplagiat', 'webhooksecret') ?: '');
$sig = $_SERVER['HTTP_X_ANTIPLAGIAT_SIGNATURE'] ?? '';

if ($secret !== '') {
    $expected = hash_hmac('sha256', $raw, $secret);
    if (!hash_equals($expected, $sig)) {
        http_response_code(401);
        echo json_encode(['error' => 'invalid signature']);
        exit;
    }
}

$payload = json_decode($raw, true);
if (empty($payload['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'missing id']);
    exit;
}

global $DB;
$front = rtrim(get_config('plagiarism_antiplagiat', 'frontendurl') ?: '', '/');
$record = $DB->get_record('plagiarism_antiplagiat_files', ['checkid' => $payload['id']]);
if (!$record) {
    // Accept unknown checks gracefully (another Moodle / race).
    http_response_code(200);
    echo json_encode(['ok' => true, 'matched' => false]);
    exit;
}

$record->status = ($payload['status'] ?? '') === 'done' ? 'done' : 'failed';
$record->similarity = $payload['similarity_percent'] ?? null;
$record->aipercent = $payload['ai_percent'] ?? null;
$record->reporturl = $front ? ($front . '/verify/' . $payload['id']) : null;
$record->error = $payload['error_message'] ?? null;
$record->timemodified = time();
$DB->update_record('plagiarism_antiplagiat_files', $record);

header('Content-Type: application/json');
echo json_encode(['ok' => true, 'matched' => true]);
