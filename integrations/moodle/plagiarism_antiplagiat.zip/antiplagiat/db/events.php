<?php
defined('MOODLE_INTERNAL') || die();

$observers = [
    [
        'eventname' => '\assignsubmission_file\event\assessable_uploaded',
        'callback'  => 'plagiarism_antiplagiat_event_handler',
        'includefile' => '/plagiarism/antiplagiat/lib.php',
    ],
    [
        'eventname' => '\assignsubmission_onlinetext\event\assessable_uploaded',
        'callback'  => 'plagiarism_antiplagiat_event_handler',
        'includefile' => '/plagiarism/antiplagiat/lib.php',
    ],
];
