<?php
defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {
    $settings->add(new admin_setting_configtext(
        'plagiarism_antiplagiat/apiurl',
        get_string('apiurl', 'plagiarism_antiplagiat'),
        get_string('apiurl_desc', 'plagiarism_antiplagiat'),
        '',
        PARAM_URL
    ));
    $settings->add(new admin_setting_configpasswordunmask(
        'plagiarism_antiplagiat/apikey',
        get_string('apikey', 'plagiarism_antiplagiat'),
        get_string('apikey_desc', 'plagiarism_antiplagiat'),
        ''
    ));
    $settings->add(new admin_setting_configpasswordunmask(
        'plagiarism_antiplagiat/webhooksecret',
        get_string('webhooksecret', 'plagiarism_antiplagiat'),
        get_string('webhooksecret_desc', 'plagiarism_antiplagiat'),
        ''
    ));
    $settings->add(new admin_setting_configtext(
        'plagiarism_antiplagiat/frontendurl',
        get_string('frontendurl', 'plagiarism_antiplagiat'),
        get_string('frontendurl_desc', 'plagiarism_antiplagiat'),
        '',
        PARAM_URL
    ));
    $settings->add(new admin_setting_configtextarea(
        'plagiarism_antiplagiat/studentdisclosure',
        get_string('studentdisclosure', 'plagiarism_antiplagiat'),
        '',
        get_string('studentdisclosure_default', 'plagiarism_antiplagiat')
    ));
}
