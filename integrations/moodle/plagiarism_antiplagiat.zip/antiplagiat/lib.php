<?php
defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/plagiarism/lib.php');

class plagiarism_plugin_antiplagiat extends plagiarism_plugin {

    public function get_links($linkarray) {
        global $DB, $OUTPUT;

        $cmid = $linkarray['cmid'] ?? 0;
        $userid = $linkarray['userid'] ?? 0;
        $file = $linkarray['file'] ?? null;
        if (!$cmid || !$userid) {
            return '';
        }

        $identifier = '';
        if ($file && method_exists($file, 'get_pathnamehash')) {
            $identifier = $file->get_pathnamehash();
        } else if (!empty($linkarray['content'])) {
            $identifier = sha1($linkarray['content']);
        } else {
            return '';
        }

        $record = $DB->get_record('plagiarism_antiplagiat_files', [
            'cm' => $cmid,
            'userid' => $userid,
            'identifier' => $identifier,
        ]);
        if (!$record) {
            return '';
        }

        $html = html_writer::start_tag('div', ['class' => 'plagiarism_antiplagiat']);
        if ($record->status === 'pending' || $record->status === 'processing') {
            $html .= html_writer::span(get_string('pending', 'plagiarism_antiplagiat'), 'badge badge-info');
        } else if ($record->status === 'failed') {
            $html .= html_writer::span(get_string('failed', 'plagiarism_antiplagiat'), 'badge badge-danger');
        } else {
            $sim = isset($record->similarity) ? format_float($record->similarity, 1) . '%' : '—';
            $ai = isset($record->aipercent) ? format_float($record->aipercent, 1) . '%' : '—';
            $html .= html_writer::span(
                get_string('similarity', 'plagiarism_antiplagiat') . ': ' . $sim,
                'badge badge-warning'
            );
            $html .= ' ';
            $html .= html_writer::span(
                get_string('ai', 'plagiarism_antiplagiat') . ': ' . $ai,
                'badge badge-secondary'
            );
            if (!empty($record->reporturl)) {
                $html .= ' ' . html_writer::link(
                    $record->reporturl,
                    get_string('viewreport', 'plagiarism_antiplagiat'),
                    ['target' => '_blank', 'rel' => 'noopener']
                );
            }
        }
        $html .= html_writer::end_tag('div');
        return $html;
    }

    public function get_form_elements_module($mform, $context, $modulename = '') {
        if (!has_capability('plagiarism/antiplagiat:enable', $context)) {
            return;
        }
        $mform->addElement(
            'checkbox',
            'antiplagiat_use',
            get_string('useantiplagiat', 'plagiarism_antiplagiat')
        );
        $mform->addHelpButton('antiplagiat_use', 'useantiplagiat', 'plagiarism_antiplagiat');
    }

    public function save_form_elements($data) {
        global $DB;
        if (empty($data->coursemodule)) {
            return;
        }
        $enabled = !empty($data->antiplagiat_use) ? 1 : 0;
        $existing = $DB->get_record('config_plugins', [
            'plugin' => 'plagiarism_antiplagiat',
            'name' => 'enabled_cm_' . $data->coursemodule,
        ]);
        if ($existing) {
            $existing->value = $enabled;
            $DB->update_record('config_plugins', $existing);
        } else {
            $DB->insert_record('config_plugins', (object)[
                'plugin' => 'plagiarism_antiplagiat',
                'name' => 'enabled_cm_' . $data->coursemodule,
                'value' => $enabled,
            ]);
        }
    }

    public function get_configs() {
        return ['antiplagiat_use'];
    }
}

/**
 * Hook: file / online text submitted.
 */
function plagiarism_antiplagiat_event_handler($eventdata) {
    global $CFG, $DB;

    $apiurl = trim(get_config('plagiarism_antiplagiat', 'apiurl') ?: '');
    $apikey = trim(get_config('plagiarism_antiplagiat', 'apikey') ?: '');
    $front = rtrim(get_config('plagiarism_antiplagiat', 'frontendurl') ?: '', '/');
    if ($apiurl === '' || $apikey === '') {
        return true;
    }

    $cmid = $eventdata->contextinstanceid ?? ($eventdata['contextinstanceid'] ?? 0);
    $userid = $eventdata->userid ?? ($eventdata['userid'] ?? 0);
    if (!$cmid || !$userid) {
        return true;
    }

    $enabled = get_config('plagiarism_antiplagiat', 'enabled_cm_' . $cmid);
    if (empty($enabled)) {
        return true;
    }

    $files = [];
    if (!empty($eventdata->other['pathnamehashes'])) {
        foreach ($eventdata->other['pathnamehashes'] as $hash) {
            $fs = get_file_storage();
            $file = $fs->get_file_by_hash($hash);
            if ($file && !$file->is_directory()) {
                $files[] = $file;
            }
        }
    }

    $callback = $CFG->wwwroot . '/plagiarism/antiplagiat/callback.php';

    foreach ($files as $file) {
        plagiarism_antiplagiat_send_file($file, $cmid, $userid, $apiurl, $apikey, $callback, $front);
    }

    // Online text
    if (!empty($eventdata->other['content'])) {
        plagiarism_antiplagiat_send_text(
            $eventdata->other['content'],
            $cmid,
            $userid,
            $apiurl,
            $apikey,
            $callback,
            $front
        );
    }

    return true;
}

function plagiarism_antiplagiat_send_file($file, $cmid, $userid, $apiurl, $apikey, $callback, $front) {
    global $DB, $CFG;

    require_once($CFG->libdir . '/filelib.php');

    $identifier = $file->get_pathnamehash();
    $filename = $file->get_filename();
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if (!in_array($ext, ['docx', 'pdf'], true)) {
        return;
    }

    $tmp = make_temp_directory('antiplagiat') . '/' . $filename;
    $file->copy_content_to($tmp);

    $curl = new curl();
    $curl->setHeader(['X-API-Key: ' . $apikey]);
    $response = $curl->post(rtrim($apiurl, '/') . '/api/v1/checks', [
        'file' => new curl_file($tmp, $file->get_mimetype(), $filename),
        'work_title' => $filename,
        'student_id' => (string)$userid,
        'student_name' => fullname(core_user::get_user($userid)),
        'webhook_url' => $callback,
    ]);
    @unlink($tmp);

    $data = json_decode($response, true);
    $now = time();
    $record = $DB->get_record('plagiarism_antiplagiat_files', [
        'cm' => $cmid,
        'userid' => $userid,
        'identifier' => $identifier,
    ]);
    $fields = (object)[
        'cm' => $cmid,
        'userid' => $userid,
        'identifier' => $identifier,
        'filename' => $filename,
        'checkid' => $data['id'] ?? null,
        'status' => !empty($data['id']) ? 'processing' : 'failed',
        'error' => empty($data['id']) ? substr($response, 0, 500) : null,
        'timemodified' => $now,
    ];
    if ($record) {
        $fields->id = $record->id;
        $DB->update_record('plagiarism_antiplagiat_files', $fields);
    } else {
        $fields->timecreated = $now;
        $DB->insert_record('plagiarism_antiplagiat_files', $fields);
    }
}

function plagiarism_antiplagiat_send_text($text, $cmid, $userid, $apiurl, $apikey, $callback, $front) {
    global $DB, $CFG;
    require_once($CFG->libdir . '/filelib.php');

    $text = trim(strip_tags($text));
    if (strlen($text) < 50) {
        return;
    }
    $identifier = sha1($text);
    $curl = new curl();
    $curl->setHeader(['X-API-Key: ' . $apikey]);
    $response = $curl->post(rtrim($apiurl, '/') . '/api/v1/checks', [
        'text_content' => $text,
        'work_title' => 'Online text',
        'student_id' => (string)$userid,
        'student_name' => fullname(core_user::get_user($userid)),
        'webhook_url' => $callback,
    ]);
    $data = json_decode($response, true);
    $now = time();
    $record = $DB->get_record('plagiarism_antiplagiat_files', [
        'cm' => $cmid,
        'userid' => $userid,
        'identifier' => $identifier,
    ]);
    $fields = (object)[
        'cm' => $cmid,
        'userid' => $userid,
        'identifier' => $identifier,
        'filename' => 'online.txt',
        'checkid' => $data['id'] ?? null,
        'status' => !empty($data['id']) ? 'processing' : 'failed',
        'error' => empty($data['id']) ? substr($response, 0, 500) : null,
        'timemodified' => $now,
    ];
    if ($record) {
        $fields->id = $record->id;
        $DB->update_record('plagiarism_antiplagiat_files', $fields);
    } else {
        $fields->timecreated = $now;
        $DB->insert_record('plagiarism_antiplagiat_files', $fields);
    }
}

/**
 * Cron: poll unfinished checks if webhook missed.
 */
function plagiarism_antiplagiat_cron() {
    global $DB, $CFG;
    require_once($CFG->libdir . '/filelib.php');

    $apiurl = trim(get_config('plagiarism_antiplagiat', 'apiurl') ?: '');
    $apikey = trim(get_config('plagiarism_antiplagiat', 'apikey') ?: '');
    $front = rtrim(get_config('plagiarism_antiplagiat', 'frontendurl') ?: '', '/');
    if ($apiurl === '' || $apikey === '') {
        return true;
    }

    $pending = $DB->get_records_select(
        'plagiarism_antiplagiat_files',
        "status IN ('pending','processing') AND checkid IS NOT NULL",
        null,
        'id ASC',
        '*',
        0,
        30
    );
    $curl = new curl();
    $curl->setHeader(['X-API-Key: ' . $apikey]);
    foreach ($pending as $row) {
        $resp = $curl->get(rtrim($apiurl, '/') . '/api/v1/checks/' . $row->checkid);
        $data = json_decode($resp, true);
        if (empty($data['status']) || $data['status'] === 'pending' || $data['status'] === 'processing') {
            continue;
        }
        $row->status = $data['status'] === 'done' ? 'done' : 'failed';
        $row->similarity = $data['similarity_percent'] ?? null;
        $row->aipercent = $data['ai_percent'] ?? null;
        $row->reporturl = $front ? ($front . '/verify/' . $row->checkid) : null;
        $row->error = $data['error_message'] ?? null;
        $row->timemodified = time();
        $DB->update_record('plagiarism_antiplagiat_files', $row);
    }
    return true;
}
